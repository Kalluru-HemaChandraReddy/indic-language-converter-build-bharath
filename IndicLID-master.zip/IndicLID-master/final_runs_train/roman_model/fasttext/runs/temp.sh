python3 prepare_corpus.py
python3 train.py
python3 inference.py
