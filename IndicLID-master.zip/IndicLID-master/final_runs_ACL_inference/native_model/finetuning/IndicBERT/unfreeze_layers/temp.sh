python3 train.py $1
python3 inference.py $1